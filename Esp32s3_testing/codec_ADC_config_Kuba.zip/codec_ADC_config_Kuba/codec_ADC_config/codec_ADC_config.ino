/*
Pin Connection
                          ESP32S3       Codec

Power	                    3.3V          VCC
Ground	                  GND	          GND
I2C Serial Clock         	D5            SCL
I2C Serial Data    	      D4    	      SDA
I2S Bit Clock             D3            CLK
I2S word select           D2    	      WS
I2S Data	                D1    	      TX_SDA

*/

#include <SparkFun_WM8960_Arduino_Library.h>
#include <Wire.h>
#include "driver/i2s_std.h"

#define I2C_SCL D5
#define I2C_SDA D4
#define I2S_CLK_PIN D3
#define I2S_WS_PIN D2
#define I2S_TX_SDA_PIN D1

#define SAMPLE_RATE      44100  // 44.1 kHz
#define BUFFER_SIZE      1024   // Rozmiar bufora w bajtach

const int16_t PLOT_MIN = -32768; // Dolna granica (zakres int16)
const int16_t PLOT_MAX = 32767;


WM8960 codec;

void codec_setup(){

  //reset
  codec.reset();

  //clock configuration
  //f_MCLK = 24MHz (XO on a board)
  codec.enablePLL();
  codec.setPLLPRESCALE(WM8960_PLLPRESCALE_DIV_2);
  codec.setSYSCLKDIV(WM8960_SYSCLK_DIV_BY_2); 
  codec.setPLLN(7);
  codec.setPLLK(134, 194, 38); //0x86C226h
  codec.setSMD(1);
  codec.setCLKSEL(WM8960_CLKSEL_PLL);

  // power
  codec.enableVREF();
  codec.enableVMID();
  // power mixer
  codec.enableAINR();
  // power PGA
  codec.enableRMIC();

  //Mic bias nic nie daje
  //codec.enableMicBias();
  //codec.setMicBiasVoltage(WM8960_MIC_BIAS_VOLTAGE_0_9_AVDD);

  // connect INPUT R1 to PGA
  codec.connectRMN1();

  // disable mute on PGA
  codec.disableRINMUTE();
  // connect PGA output to boost mixer
  codec.connectRMIC2B();

  // PGA volume in dB
  codec.setRINVOLDB(0.00);

  //ADC configuration
  codec.enableAdcRight();

  codec.setWL(WM8960_WL_16BIT);
}

i2s_chan_handle_t rx_handle;



size_t bytes_read = 0;

void setup() {
  
  Serial.begin(115200);

  Wire.begin(I2C_SDA, I2C_SCL);

  if (!codec.begin())
  {
    Serial.println("The device did not respond. Please check wiring.");
    while (1);
  }

  codec_setup();

  i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_AUTO, I2S_ROLE_MASTER);
    i2s_new_channel(&chan_cfg, NULL, &rx_handle);

    // 2. Konfiguracja standardu dla 16-bit 44.1kHz STEREO
    // Nawet jeśli dane są tylko na prawym, I2S zazwyczaj pracuje w parach L/R
    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)I2S_CLK_PIN,
            .ws = (gpio_num_t)I2S_WS_PIN,
            .dout = I2S_GPIO_UNUSED,
            .din = (gpio_num_t)I2S_TX_SDA_PIN,
            .invert_flags = { .mclk_inv = false, .bclk_inv = false, .ws_inv = false }

            //#define I2C_SCL D5
            //#define I2C_SDA D4
            //#define I2S_CLK_PIN D3
            //#define I2S_WS_PIN D2
            //#define I2S_TX_SDA_PIN D1

        }
  };
  i2s_channel_init_std_mode(rx_handle, &std_cfg);
  i2s_channel_enable(rx_handle);
}

void loop() {
  
 int16_t raw_samples[BUFFER_SIZE]; // Próbki 16-bitowe
    size_t bytes_read = 0;

    // Odczyt danych
    if (i2s_channel_read(rx_handle, &raw_samples, sizeof(raw_samples), &bytes_read, 1000) == ESP_OK) {
        int samples_count = bytes_read / sizeof(int16_t);

        for (int i = 0; i < samples_count; i++) {
            // W trybie STEREO: [0]=L, [1]=R, [2]=L, [3]=R...
            // Wybieramy tylko prawy kanał (indeksy nieparzyste)
            if (i % 2 != 0) {
                // Przy 16 bitach dane są zazwyczaj gotowe do wyświetlenia
                // Bezpośrednie wysyłanie na Plotter:
                Serial.print(PLOT_MIN);
                Serial.print(" ");
                Serial.print(PLOT_MAX);
                Serial.print(" ");
                Serial.println(raw_samples[i]);
            }
        }
    }


  

}
